#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

CURRENT = Path(__file__).resolve().parent
if str(CURRENT) not in sys.path:
    sys.path.insert(0, str(CURRENT))

import shop3345 as base  # noqa: E402


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Automation wrapper voor 3345 scraper")
    parser.add_argument(
        "--mode",
        choices=["links", "discovery", "refresh-known", "backfill", "both"],
        default="both",
    )
    parser.add_argument("--max-pages", type=int, default=15)
    parser.add_argument("--limit-details", type=int, default=250)
    parser.add_argument("--workers", type=int, default=10)
    parser.add_argument("--links-file", default="data/raw/shop3345/3345_product_links.txt")
    parser.add_argument("--csv-file", default="data/raw/shop3345/3345_products.csv")
    parser.add_argument("--state-file", default="data/raw/shop3345/3345_detail_rotation_state.json")
    parser.add_argument(
        "--source",
        action="append",
        dest="sources",
        default=None,
        help="Discovery source(s), repeatable.",
    )
    return parser


def ensure_parent(path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)


def main() -> int:
    args = build_parser().parse_args()

    links_file = Path(args.links_file)
    csv_file = Path(args.csv_file)
    state_file = Path(args.state_file)

    ensure_parent(links_file)
    ensure_parent(csv_file)
    ensure_parent(state_file)

    session = base.build_session()
    sources = args.sources or ["browse-all-music", "all"]

    if args.mode in {"links", "discovery"}:
        new_links = base.scrape_listing_pages(
            session=session,
            links_file=links_file,
            state_file=state_file,
            source_names=sources,
            max_pages_per_source=max(1, args.max_pages),
            csv_path=csv_file,
        )
        print(f"[DISCOVERY] nieuw opgeslagen links: {len(new_links)}")
        print("Klaar.")
        return 0

    if args.mode == "refresh-known":
        new_links = base.scrape_listing_pages(
            session=session,
            links_file=links_file,
            state_file=state_file,
            source_names=sources,
            max_pages_per_source=max(1, args.max_pages),
            csv_path=csv_file,
        )
        rows_by_url = base.load_csv_rows_by_url(csv_file, base.get_fieldnames())
        listing_scope = [
            url for url, row in rows_by_url.items() if (row.get("source_collection") in sources or not row.get("source_collection"))
        ]
        targets = base.pick_detail_targets_from_listing(
            rows_by_url=rows_by_url,
            listing_urls_seen=listing_scope,
            new_links=new_links,
            limit_details=args.limit_details,
            state_file=state_file,
        )
        written = base.scrape_product_details(
            session=session,
            links=targets,
            csv_path=csv_file,
            update_existing=True,
            workers=max(1, args.workers),
            state_file=state_file,
            rows_by_url=rows_by_url,
            status_prefix="REFRESH-KNOWN",
        )
        print(
            f"[REFRESH-KNOWN] listing refresh + detail refresh voltooid | scope={len(listing_scope)} | "
            f"nieuw_gevonden={len(new_links)} | detail_targets={len(targets)} | verwerkt={written}"
        )
        print("Klaar.")
        return 0

    if args.mode == "backfill":
        targets = base.select_backfill_targets(
            links_file=links_file,
            csv_file=csv_file,
            limit_details=args.limit_details,
            state_file=state_file,
        )
        rows_by_url = base.load_csv_rows_by_url(csv_file, base.get_fieldnames())
        written = base.scrape_product_details(
            session=session,
            links=targets,
            csv_path=csv_file,
            update_existing=True,
            workers=max(1, args.workers),
            state_file=state_file,
            rows_by_url=rows_by_url,
            status_prefix="BACKFILL",
        )
        print(f"[DETAILS] verwerkt: {written}")
        print("Klaar.")
        return 0

    # mixed mode: discovery/listing refresh + detail targets
    new_links = base.scrape_listing_pages(
        session=session,
        links_file=links_file,
        state_file=state_file,
        source_names=sources,
        max_pages_per_source=max(1, args.max_pages),
        csv_path=csv_file,
    )
    rows_by_url = base.load_csv_rows_by_url(csv_file, base.get_fieldnames())
    listing_urls_seen = list(rows_by_url.keys())
    targets = base.pick_detail_targets_from_listing(
        rows_by_url=rows_by_url,
        listing_urls_seen=listing_urls_seen,
        new_links=new_links,
        limit_details=args.limit_details,
        state_file=state_file,
    )
    written = base.scrape_product_details(
        session=session,
        links=targets,
        csv_path=csv_file,
        update_existing=True,
        workers=max(1, args.workers),
        state_file=state_file,
        rows_by_url=rows_by_url,
        status_prefix="DETAIL",
    )
    print(f"[DETAILS] verwerkt: {written}")
    print("Klaar.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
