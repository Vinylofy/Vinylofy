#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
import threading
import time
import uuid
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple
from urllib.parse import urljoin, urlsplit, urlunsplit

import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE_DOMAIN = "https://bobsvinyl.nl"
BASE_COLLECTION_URL = "https://bobsvinyl.nl/collections/all"
COLLECTION_NAME = "all"
DEFAULT_DELAY_SECONDS = 0.20
DEFAULT_WORKERS = 5
DEFAULT_BATCH_SIZE = 500
TIMEOUT = 30
DETAIL_FETCH_RETRIES = 3
DETAIL_RETRY_SLEEP_SECONDS = 1.2
STEP1_FILENAME = "bobsvinyl_step1.csv"
STEP2_FILENAME = "bobsvinyl_step2_enriched.csv"
DETAIL_ISSUES_FILENAME = "bobsvinyl_missing_eans.csv"
DEFAULT_STATE_FILENAME = "bobsvinyl_detail_rotation_state.json"

RESOLVED_DETAIL_STATUSES = {"ok", "2e_hands_bevestigd"}

STEP1_COLUMNS = [
    "url",
    "url_listing",
    "product_handle",
    "artist",
    "title",
    "drager",
    "prijs",
    "price_checked_at",
    "bron_collectie",
    "bron_listing_urls",
]

STEP2_COLUMNS = STEP1_COLUMNS + [
    "ean",
    "mogelijk_2e_hands",
    "detail_status",
    "detail_opmerking",
    "detail_checked_at",
]

DETAIL_ISSUE_COLUMNS = [
    "url",
    "artist",
    "title",
    "drager",
    "prijs",
    "price_checked_at",
    "ean",
    "mogelijk_2e_hands",
    "detail_status",
    "detail_opmerking",
    "detail_checked_at",
]

_thread_local = threading.local()

def set_csv_field_size_limit() -> None:
    limit = sys.maxsize
    while True:
        try:
            csv.field_size_limit(limit)
            return
        except OverflowError:
            limit //= 10


set_csv_field_size_limit()



def make_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=4,
        connect=4,
        read=4,
        backoff_factor=1,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=("GET",),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=50, pool_maxsize=50)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update(
        {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/145.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "nl-NL,nl;q=0.9,en;q=0.8",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        }
    )
    return session


def get_thread_session(force_new: bool = False) -> requests.Session:
    session = getattr(_thread_local, "session", None)
    if force_new and session is not None:
        try:
            session.close()
        except Exception:
            pass
        session = None

    if session is None:
        session = make_session()
        _thread_local.session = session
    return session


def normalize_text(value: str | None) -> str:
    if value is None:
        return ""
    value = value.replace("\xa0", " ")
    return re.sub(r"\s+", " ", value).strip()


def nl_price(value: str) -> str:
    value = normalize_text(value)
    value = value.replace("€", "").replace("EUR", "").strip()
    value = value.replace(" ", "")
    return value.replace(".", ",")


def unique_pipe_join(existing: str, new_value: str, max_items: int = 20) -> str:
    items = [x for x in (existing or "").split(" | ") if x]
    if new_value and new_value not in items:
        items.append(new_value)
    if len(items) > max_items:
        items = items[-max_items:]
    return " | ".join(items)



def canonical_product_url(url: str) -> str:
    absolute = urljoin(BASE_DOMAIN, url)
    parts = urlsplit(absolute)
    path = parts.path.rstrip("/")
    if not path:
        path = "/"
    return urlunsplit((parts.scheme, parts.netloc, path, "", ""))


def collection_page_url(page: int) -> str:
    if page <= 1:
        return BASE_COLLECTION_URL
    return f"{BASE_COLLECTION_URL}?page={page}"


def product_handle_from_url(url: str) -> str:
    path = urlsplit(url).path.rstrip("/")
    if not path:
        return ""
    return path.split("/")[-1]


def now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def ensure_directory(path: str | Path) -> Path:
    directory = Path(path)
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def step1_path(output_dir: Path) -> Path:
    return output_dir / STEP1_FILENAME


def step2_path(output_dir: Path) -> Path:
    return output_dir / STEP2_FILENAME


def issues_path(output_dir: Path) -> Path:
    return output_dir / DETAIL_ISSUES_FILENAME


def default_state_path(output_dir: Path) -> Path:
    return output_dir / DEFAULT_STATE_FILENAME


def load_csv_as_dict(path: Path, columns: List[str]) -> Dict[str, Dict[str, str]]:
    rows: Dict[str, Dict[str, str]] = OrderedDict()
    if not path.exists():
        return rows

    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for raw in reader:
            raw_url = normalize_text(raw.get("url", ""))
            if not raw_url:
                continue
            url = canonical_product_url(raw_url)
            row = {col: normalize_text(raw.get(col, "")) for col in columns}
            row["url"] = url
            if not row.get("product_handle"):
                row["product_handle"] = product_handle_from_url(url)
            if not row.get("bron_collectie"):
                row["bron_collectie"] = COLLECTION_NAME
            rows[url] = row
    return rows


def write_csv(path: Path, rows_by_url: Dict[str, Dict[str, str]], columns: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_name(f"{path.name}.{uuid.uuid4().hex}.tmp")

    with temp_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for _, row in sorted(
            rows_by_url.items(),
            key=lambda item: (
                normalize_text(item[1].get("artist", "")).lower(),
                normalize_text(item[1].get("title", "")).lower(),
                item[0],
            ),
        ):
            safe_row = {col: normalize_text(row.get(col, "")) for col in columns}
            writer.writerow(safe_row)

    last_error: Exception | None = None
    for attempt in range(12):
        try:
            os.replace(temp_path, path)
            return
        except PermissionError as exc:
            last_error = exc
            time.sleep(0.5 + (attempt * 0.15))
        except Exception:
            try:
                temp_path.unlink(missing_ok=True)
            except Exception:
                pass
            raise

    backup_path = path.with_name(f"{path.stem}_write_failed_{int(time.time())}{path.suffix}")
    try:
        os.replace(temp_path, backup_path)
    except Exception:
        pass

    raise PermissionError(
        f"Kon {path.name} niet overschrijven. Sluit Excel/preview/OneDrive lock op dit bestand en probeer opnieuw. "
        f"Eventuele noodkopie: {backup_path.name}"
    ) from last_error


def write_detail_issues(path: Path, rows_by_url: Dict[str, Dict[str, str]]) -> None:
    issue_rows: Dict[str, Dict[str, str]] = OrderedDict()
    for url, row in rows_by_url.items():
        ean = normalize_text(row.get("ean", ""))
        status = normalize_text(row.get("detail_status", ""))
        if ean:
            continue
        if status in RESOLVED_DETAIL_STATUSES:
            continue
        if not status:
            continue

        issue_rows[url] = {col: normalize_text(row.get(col, "")) for col in DETAIL_ISSUE_COLUMNS}
        issue_rows[url]["url"] = url

    write_csv(path, issue_rows, DETAIL_ISSUE_COLUMNS)


def fetch_soup(session: requests.Session, url: str) -> BeautifulSoup:
    response = session.get(url, timeout=TIMEOUT)
    response.raise_for_status()
    return BeautifulSoup(response.text, "html.parser")


def extract_price(card) -> str:
    sale = card.select_one(".price-item--sale.price-item--last")
    regular = card.select_one(".price-item--regular")
    node = sale or regular
    return nl_price(node.get_text(" ", strip=True) if node else "")


def split_artist_title_drager(raw_title: str) -> Tuple[str, str, str]:
    text = normalize_text(raw_title)
    if not text:
        return "", "", ""

    drager = ""
    match = re.search(r"\(([^()]*)\)\s*$", text)
    if match:
        candidate = normalize_text(match.group(1))
        if candidate and len(candidate) <= 30:
            drager = candidate
            text = normalize_text(text[: match.start()])

    artist = ""
    title = text
    if " - " in text:
        artist, title = text.split(" - ", 1)
    elif " – " in text:
        artist, title = text.split(" – ", 1)

    return normalize_text(artist), normalize_text(title), normalize_text(drager)


def parse_listing_card(card, listing_url: str) -> Dict[str, str] | None:
    link = card.select_one('a.full-unstyled-link[href*="/products/"]') or card.select_one('a[href*="/products/"]')
    if link is None:
        return None

    href = normalize_text(link.get("href", ""))
    if not href or "/products/" not in href:
        return None

    raw_title = normalize_text(link.get_text(" ", strip=True))
    artist, title, drager = split_artist_title_drager(raw_title)
    if not title and raw_title:
        title = raw_title

    listing_absolute = urljoin(BASE_DOMAIN, href)
    canonical = canonical_product_url(listing_absolute)
    prijs = extract_price(card)

    return {
        "url": canonical,
        "url_listing": listing_absolute,
        "product_handle": product_handle_from_url(canonical),
        "artist": artist,
        "title": title,
        "drager": drager,
        "prijs": prijs,
        "price_checked_at": now_iso(),
        "bron_collectie": COLLECTION_NAME,
        "bron_listing_urls": listing_url,
    }


def merge_row(existing: Dict[str, str] | None, incoming: Dict[str, str], columns: List[str]) -> Dict[str, str]:
    if existing is None:
        merged = {col: "" for col in columns}
        merged.update(incoming)
        return merged

    merged = dict(existing)
    for key, value in incoming.items():
        if key == "bron_listing_urls":
            merged[key] = unique_pipe_join(merged.get(key, ""), value)
        elif value:
            merged[key] = value

    for col in columns:
        merged.setdefault(col, "")
    return merged


def print_threadsafe(lock: threading.Lock, message: str) -> None:
    with lock:
        print(message, flush=True)


def scrape_all_listings(
    output_path: Path,
    columns: List[str],
    workers: int = DEFAULT_WORKERS,
    load_from_path: Path | None = None,
    delay_seconds: float = DEFAULT_DELAY_SECONDS,
    stop_on_no_new_urls: bool = False,
) -> Dict[str, Dict[str, str]]:
    del workers

    load_path = load_from_path or output_path
    rows_by_url = load_csv_as_dict(load_path, columns)

    if rows_by_url:
        print(f"[INFO] Bestaand bestand geladen: {load_path} ({len(rows_by_url)} records)")
    else:
        print(f"[INFO] Start met leeg bestand: {output_path}")

    session = make_session()
    total_pages = 0
    page = 1
    seen_urls = set(rows_by_url.keys())

    while True:
        current_url = collection_page_url(page)
        try:
            soup = fetch_soup(session, current_url)
        except Exception as exc:
            print(f"[FOUT] collectie | pagina {page} kon niet worden geladen: {exc}")
            break

        cards = soup.select("div.card-wrapper.product-card-wrapper")
        parsed_rows: List[Dict[str, str]] = []
        page_urls: List[str] = []

        for card in cards:
            row = parse_listing_card(card, current_url)
            if row is None:
                continue
            parsed_rows.append(row)
            page_urls.append(row["url"])

        if not parsed_rows:
            print(f"[STOP] collectie {COLLECTION_NAME} | pagina {page} bevat geen producten meer.")
            break

        unique_page_urls = set(page_urls)
        new_on_page = [url for url in unique_page_urls if url not in seen_urls]

        new_for_file = 0
        updated_for_file = 0
        for row in parsed_rows:
            row_url = row["url"]
            existing = rows_by_url.get(row_url)
            if existing is None:
                new_for_file += 1
            else:
                updated_for_file += 1
            rows_by_url[row_url] = merge_row(existing, row, columns)

        write_csv(output_path, rows_by_url, columns)

        seen_urls.update(unique_page_urls)
        total_pages += 1

        print(
            f"[OK] collectie {COLLECTION_NAME} | pagina {page} | producten: {len(parsed_rows)} | "
            f"unieke op pagina: {len(unique_page_urls)} | nieuw in bestand: {new_for_file} | "
            f"geüpdatet: {updated_for_file} | totaal bestand: {len(rows_by_url)}",
            flush=True,
        )

        if stop_on_no_new_urls and not new_on_page and page > 1:
            print(f"[STOP] collectie {COLLECTION_NAME} | pagina {page} bracht geen nieuwe URL's meer.")
            break

        page += 1
        time.sleep(delay_seconds)

    print(f"[KLAAR] {output_path} opgeslagen met {len(rows_by_url)} records uit {total_pages} pagina's.")
    return rows_by_url


def collect_product_text(soup: BeautifulSoup) -> str:
    product_title = normalize_text(
        soup.select_one(".product__title h1").get_text(" ", strip=True) if soup.select_one(".product__title h1") else ""
    )
    info_container = normalize_text(
        soup.select_one(".product__info-container").get_text(" ", strip=True)
        if soup.select_one(".product__info-container")
        else ""
    )
    description_container = normalize_text(
        soup.select_one(".product__description").get_text(" ", strip=True)
        if soup.select_one(".product__description")
        else ""
    )
    return " ".join(x for x in [product_title, info_container, description_container] if x)


def validate_product_page(soup: BeautifulSoup) -> Tuple[bool, str]:
    title = normalize_text(
        soup.select_one(".product__title h1").get_text(" ", strip=True) if soup.select_one(".product__title h1") else ""
    )
    has_info_container = soup.select_one(".product__info-container") is not None
    has_description = soup.select_one(".product__description") is not None
    has_price = soup.select_one(".price.price--large, .price__container") is not None
    has_add_to_cart = soup.select_one("form[action*='/cart/add']") is not None

    if not title:
        return False, "geen producttitel gevonden"
    if not has_info_container:
        return False, "geen product-info-container gevonden"
    if not (has_description or has_price or has_add_to_cart):
        return False, "productpagina lijkt incompleet"
    return True, "ok"


def extract_labeled_ean(text: str) -> str:
    normalized = normalize_text(text)
    if not normalized:
        return ""

    patterns = [
        r"\bEAN(?:[\s-]*code)?\b\s*[:#-]?\s*([0-9]{8,14})",
        r"\bbarcode\b\s*[:#-]?\s*([0-9]{8,14})",
        r"\bgtin(?:8|12|13|14)?\b\s*[:=]\s*['\"]?([0-9]{8,14})",
    ]
    for pattern in patterns:
        match = re.search(pattern, normalized, flags=re.IGNORECASE)
        if match:
            return match.group(1)
    return ""


def extract_ean_from_soup(soup: BeautifulSoup, product_text: str) -> str:
    info_container = soup.select_one(".product__info-container")
    description = soup.select_one(".product__description")

    primary_texts: List[str] = []
    if info_container is not None:
        primary_texts.append(info_container.get_text(" ", strip=True))
        primary_texts.append(str(info_container))
    if description is not None:
        primary_texts.append(description.get_text(" ", strip=True))
        primary_texts.append(str(description))
    if product_text:
        primary_texts.append(product_text)

    for text in primary_texts:
        ean = extract_labeled_ean(text)
        if ean:
            return ean

    candidate_texts: List[str] = list(primary_texts)

    for script in soup.select("script"):
        script_text = script.string or script.get_text(" ", strip=True)
        if not script_text:
            continue
        lowered = script_text.lower()
        if any(token in lowered for token in ["gtin", "barcode", "ean"]):
            candidate_texts.append(script_text)

    patterns = [
        r"\bEAN(?:[\s-]*code)?\b\s*[:#-]?\s*([0-9]{8,14})",
        r"\bbarcode\b\s*[:#-]?\s*([0-9]{8,14})",
        r"\bgtin(?:8|12|13|14)?\b\s*[:=]\s*['\"]?([0-9]{8,14})",
        r"['\"]gtin(?:8|12|13|14)?['\"]\s*:\s*['\"]([0-9]{8,14})",
        r"['\"]barcode['\"]\s*:\s*['\"]([0-9]{8,14})",
        r"['\"]ean['\"]\s*:\s*['\"]([0-9]{8,14})",
    ]

    for text in candidate_texts:
        normalized = normalize_text(text)
        if not normalized:
            continue
        for pattern in patterns:
            match = re.search(pattern, normalized, flags=re.IGNORECASE)
            if match:
                return match.group(1)
    return ""
def detect_second_hand(soup: BeautifulSoup, product_text: str) -> str:
    lowered = product_text.lower()
    second_hand_patterns = [
        r"\b2e\s*hands?\b",
        r"\btweedehands\b",
        r"\bsecond\s*hand\b",
        r"\bused\b",
        r"\bpre[-\s]?owned\b",
    ]
    if any(re.search(pattern, lowered, flags=re.IGNORECASE) for pattern in second_hand_patterns):
        return "JA"

    html_blocks = []
    for selector in [".product__title", ".product__info-container", ".product__description"]:
        node = soup.select_one(selector)
        if node is not None:
            html_blocks.append(normalize_text(node.get_text(" ", strip=True)).lower())
    html_text = " ".join(html_blocks)
    if any(re.search(pattern, html_text, flags=re.IGNORECASE) for pattern in second_hand_patterns):
        return "JA"

    return "NEE"


def parse_detail_result(soup: BeautifulSoup) -> Tuple[bool, str, str, str]:
    valid_page, validation_note = validate_product_page(soup)
    if not valid_page:
        return False, "", "", validation_note

    product_text = collect_product_text(soup)
    ean = extract_ean_from_soup(soup, product_text)
    second_hand = detect_second_hand(soup, product_text)
    return True, ean, second_hand, validation_note


def enrich_one(row: Dict[str, str]) -> Dict[str, str]:
    url = row.get("url", "")
    result = dict(row)
    last_status = ""
    last_note = ""

    for attempt in range(1, DETAIL_FETCH_RETRIES + 1):
        session = get_thread_session(force_new=(attempt > 1))
        try:
            soup = fetch_soup(session, url)
            valid_page, ean, second_hand, validation_note = parse_detail_result(soup)

            result["detail_checked_at"] = now_iso()
            result["mogelijk_2e_hands"] = second_hand or "NEE"

            if not valid_page:
                last_status = "retry_ongeldige_pagina"
                last_note = f"poging {attempt}/{DETAIL_FETCH_RETRIES}: {validation_note}"
            elif ean:
                result["ean"] = ean
                result["detail_status"] = "ok"
                result["detail_opmerking"] = ""
                result["_status"] = "ok"
                return result
            elif second_hand == "JA":
                result["ean"] = ""
                result["detail_status"] = "2e_hands_bevestigd"
                result["detail_opmerking"] = "2e hands-vermelding gevonden; geen EAN zichtbaar"
                result["_status"] = "2e hands bevestigd"
                return result
            else:
                last_status = "geen_ean_na_retries"
                last_note = f"poging {attempt}/{DETAIL_FETCH_RETRIES}: valide productpagina, maar geen EAN gevonden"

        except Exception as exc:
            result["detail_checked_at"] = now_iso()
            last_status = "fout_bij_detailfetch"
            last_note = f"poging {attempt}/{DETAIL_FETCH_RETRIES}: {exc}"

        if attempt < DETAIL_FETCH_RETRIES:
            time.sleep(DETAIL_RETRY_SLEEP_SECONDS * attempt)

    result["detail_status"] = last_status or "geen_ean_na_retries"
    result["detail_opmerking"] = last_note
    result["mogelijk_2e_hands"] = result.get("mogelijk_2e_hands", "") or "NEE"
    result["ean"] = normalize_text(result.get("ean", row.get("ean", "")))
    result["_status"] = result["detail_status"]
    return result


def needs_enrichment(row: Dict[str, str]) -> bool:
    ean = normalize_text(row.get("ean", ""))
    detail_status = normalize_text(row.get("detail_status", ""))
    if ean:
        return False
    if detail_status in RESOLVED_DETAIL_STATUSES:
        return False
    return True


def load_state(path: Path) -> dict:
    if not path.exists():
        return {"cursor": 0, "last_batch_size": 0, "updated_at": ""}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return {"cursor": 0, "last_batch_size": 0, "updated_at": ""}
        return {
            "cursor": int(data.get("cursor", 0) or 0),
            "last_batch_size": int(data.get("last_batch_size", 0) or 0),
            "updated_at": normalize_text(data.get("updated_at", "")),
        }
    except Exception:
        return {"cursor": 0, "last_batch_size": 0, "updated_at": ""}


def save_state(path: Path, cursor: int, last_batch_size: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "cursor": int(cursor),
        "last_batch_size": int(last_batch_size),
        "updated_at": now_iso(),
    }
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def select_rotating_urls(todo_urls: List[str], state_path: Path, batch_size: int | None) -> Tuple[List[str], int, int]:
    ordered = sorted(todo_urls)
    total = len(ordered)
    if total == 0:
        return [], 0, 0

    if batch_size is None or batch_size <= 0 or batch_size >= total:
        return ordered, 0, 0

    state = load_state(state_path)
    start = int(state.get("cursor", 0) or 0) % total
    end = start + batch_size
    if end <= total:
        selected = ordered[start:end]
    else:
        overflow = end - total
        selected = ordered[start:] + ordered[:overflow]

    next_cursor = (start + len(selected)) % total
    return selected, start, next_cursor


def enrich_all(
    input_path: Path,
    output_path: Path,
    issues_output_path: Path,
    state_path: Path,
    workers: int = DEFAULT_WORKERS,
    batch_size: int | None = DEFAULT_BATCH_SIZE,
    force_urls: List[str] | None = None,
) -> Dict[str, Dict[str, str]]:
    rows_by_url = load_csv_as_dict(input_path, STEP2_COLUMNS)
    if not rows_by_url:
        print(f"[INFO] Geen records gevonden in {input_path}. Eerst listings scrapen.")
        return rows_by_url

    todo_urls = [url for url, row in rows_by_url.items() if needs_enrichment(row)]
    skipped = len(rows_by_url) - len(todo_urls)

    normalized_force_urls: List[str] = []
    for url in (force_urls or []):
        normalized = canonical_product_url(url)
        if normalized not in normalized_force_urls:
            normalized_force_urls.append(normalized)

    if normalized_force_urls:
        selected_urls = [url for url in normalized_force_urls if url in rows_by_url]
        missing_force_urls = [url for url in normalized_force_urls if url not in rows_by_url]
        start_cursor = 0
        next_cursor = load_state(state_path).get("cursor", 0)
        todo_rows = {url: rows_by_url[url] for url in selected_urls}

        if missing_force_urls:
            print(f"[WAARSCHUWING] force-url niet gevonden in bronbestand: {len(missing_force_urls)}")
            for missing_url in missing_force_urls:
                print(f"[WAARSCHUWING] ontbreekt: {missing_url}")

        print(
            f"[INFO] Verrijking gestart vanuit {input_path} ({len(rows_by_url)} records | "
            f"openstaand: {len(todo_urls)} | force batch: {len(todo_rows)} | overgeslagen: {skipped})"
        )
    else:
        selected_urls, start_cursor, next_cursor = select_rotating_urls(todo_urls, state_path, batch_size)
        todo_rows = {url: rows_by_url[url] for url in selected_urls}

        print(
            f"[INFO] Verrijking gestart vanuit {input_path} ({len(rows_by_url)} records | "
            f"openstaand: {len(todo_urls)} | batch: {len(todo_rows)} | overgeslagen: {skipped} | "
            f"cursor: {start_cursor} -> {next_cursor})"
        )

    if not todo_rows:
        if output_path != input_path or not output_path.exists():
            write_csv(output_path, rows_by_url, STEP2_COLUMNS)
        write_detail_issues(issues_output_path, rows_by_url)
        if not normalized_force_urls:
            save_state(state_path, 0, 0)
        print("[KLAAR] Geen detailverrijking nodig; alle records hebben al een resolved detailstatus.")
        return rows_by_url

    rows_lock = threading.Lock()
    print_lock = threading.Lock()
    total = len(todo_rows)
    processed = 0

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(enrich_one, row): url for url, row in todo_rows.items()}

        for future in as_completed(futures):
            url = futures[future]
            enriched_row = future.result()
            processed += 1

            with rows_lock:
                rows_by_url[url] = merge_row(rows_by_url.get(url), enriched_row, STEP2_COLUMNS)
                write_csv(output_path, rows_by_url, STEP2_COLUMNS)
                write_detail_issues(issues_output_path, rows_by_url)

            artist = enriched_row.get("artist", "")
            title = enriched_row.get("title", "")
            ean = enriched_row.get("ean", "")
            second_hand = enriched_row.get("mogelijk_2e_hands", "")
            status = enriched_row.get("detail_status", enriched_row.get("_status", ""))
            note = enriched_row.get("detail_opmerking", "")
            print_threadsafe(
                print_lock,
                f"[OK] enrich {processed}/{total} | {artist} - {title} | "
                f"EAN: {ean or '-'} | mogelijk 2e hands: {second_hand or '-'} | "
                f"status: {status or '-'}{(' | ' + note) if note else ''}",
            )

    if not normalized_force_urls:
        save_state(state_path, next_cursor, len(todo_rows))
    cursor_text = f"Nieuwe cursor: {next_cursor}" if not normalized_force_urls else "Force recheck voltooid"
    print(
        f"[KLAAR] {output_path} opgeslagen met {len(rows_by_url)} records; "
        f"{total} detailpagina's verwerkt. Missersbestand: {issues_output_path.name}. "
        f"{cursor_text}"
    )
    return rows_by_url


def sync_step1_to_existing_step2(step1_rows: Dict[str, Dict[str, str]], step2_file: Path, issues_file: Path) -> None:
    if not step2_file.exists():
        return

    step2_rows = load_csv_as_dict(step2_file, STEP2_COLUMNS)
    if not step2_rows:
        return

    changed = 0
    for url, step1_row in step1_rows.items():
        if url not in step2_rows:
            continue
        merged = merge_row(step2_rows[url], step1_row, STEP2_COLUMNS)
        if merged != step2_rows[url]:
            step2_rows[url] = merged
            changed += 1

    if changed:
        write_csv(step2_file, step2_rows, STEP2_COLUMNS)
        write_detail_issues(issues_file, step2_rows)
        print(f"[SYNC] {step2_file.name} bijgewerkt met {changed} prijs/listing-updates.")


def run_step1(output_dir: Path, workers: int = DEFAULT_WORKERS, delay_seconds: float = DEFAULT_DELAY_SECONDS) -> None:
    s1 = step1_path(output_dir)
    s2 = step2_path(output_dir)
    issues = issues_path(output_dir)
    source_path = s1 if s1.exists() else (s2 if s2.exists() else s1)
    rows = scrape_all_listings(
        output_path=s1,
        columns=STEP1_COLUMNS,
        workers=workers,
        load_from_path=source_path,
        delay_seconds=delay_seconds,
        stop_on_no_new_urls=False,
    )
    sync_step1_to_existing_step2(rows, s2, issues)


def run_step2(
    output_dir: Path,
    workers: int = DEFAULT_WORKERS,
    limit_detail: int | None = DEFAULT_BATCH_SIZE,
    state_file: str | None = None,
    force_urls: List[str] | None = None,
) -> None:
    s1 = step1_path(output_dir)
    s2 = step2_path(output_dir)
    issues = issues_path(output_dir)
    state = Path(state_file) if state_file else default_state_path(output_dir)
    source_path = s2 if s2.exists() else s1
    enrich_all(
        input_path=source_path,
        output_path=s2,
        issues_output_path=issues,
        state_path=state,
        workers=workers,
        batch_size=limit_detail,
        force_urls=force_urls,
    )


def run_both(
    output_dir: Path,
    workers: int = DEFAULT_WORKERS,
    delay_seconds: float = DEFAULT_DELAY_SECONDS,
    limit_detail: int | None = DEFAULT_BATCH_SIZE,
    state_file: str | None = None,
    force_urls: List[str] | None = None,
) -> None:
    run_step1(output_dir=output_dir, workers=workers, delay_seconds=delay_seconds)
    run_step2(
        output_dir=output_dir,
        workers=workers,
        limit_detail=limit_detail,
        state_file=state_file,
        force_urls=force_urls,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Bob's Vinyl scraper for Vinylofy")
    parser.add_argument("--mode", choices=["step1", "step2", "both"], default="both")
    parser.add_argument("--workers", type=int, default=DEFAULT_WORKERS)
    parser.add_argument(
        "--limit-detail",
        type=int,
        default=DEFAULT_BATCH_SIZE,
        help="Max aantal detailpagina's per run voor EAN-verrijking (0 = alles)",
    )
    parser.add_argument("--delay-seconds", type=float, default=DEFAULT_DELAY_SECONDS)
    parser.add_argument("--output-dir", default="data/raw/bobsvinyl")
    parser.add_argument(
        "--force-url",
        action="append",
        default=[],
        help="Specifieke product-URL om direct opnieuw te verrijken; mag meerdere keren worden opgegeven",
    )
    parser.add_argument(
        "--state-file",
        default=None,
        help="Pad naar rotatiestate voor step2 (default: data/raw/bobsvinyl/bobsvinyl_detail_rotation_state.json)",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    output_dir = ensure_directory(args.output_dir)
    workers = max(1, int(args.workers))
    limit_detail = None if int(args.limit_detail) == 0 else max(1, int(args.limit_detail))
    delay_seconds = max(0.0, float(args.delay_seconds))

    if args.mode == "step1":
        run_step1(output_dir=output_dir, workers=workers, delay_seconds=delay_seconds)
        return 0
    if args.mode == "step2":
        run_step2(
            output_dir=output_dir,
            workers=workers,
            limit_detail=limit_detail,
            state_file=args.state_file,
            force_urls=args.force_url,
        )
        return 0

    run_both(
        output_dir=output_dir,
        workers=workers,
        delay_seconds=delay_seconds,
        limit_detail=limit_detail,
        state_file=args.state_file,
        force_urls=args.force_url,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
