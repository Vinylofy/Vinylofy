# 3345 gerichte extractor-fixset

Deze set is smal en gericht op het echte probleem uit de runlogs:

- EAN wordt wel gevonden
- prijs blijft leeg
- availability wordt te vaak `out_of_stock`

## Inhoud
- `patches/shop3345_extractor_fix.diff`
- `tools/apply_shop3345_extractor_fix.sh`
- `tools/shop3345_smoketest.py`

## Wat de patch doet
1. **Prijsfallbacks uitbreiden**
   - DOM prijsselectors blijven bestaan
   - extra fallback op paginatekst zoals:
     - `Default Title - €39,99`
     - `Sale price €39,99`
     - `Regular price €39,99`
   - extra fallback op `offers.price` in JSON-LD

2. **Availability-detectie repareren**
   - `Add To Cart` krijgt voorrang en resulteert in `in_stock`
   - alleen expliciete `Sold out` / `Out of stock` signalen geven `out_of_stock`
   - generieke footertekst zoals `Items no longer available` telt niet meer als sold-out signaal

3. **Geen brede herbouw**
   - alleen `scripts/scrapers/shop3345.py` wordt gepatcht

## Toepassen
```bash
bash tools/apply_shop3345_extractor_fix.sh /workspaces/Vinylofy
```

Of handmatig:
```bash
cd /workspaces/Vinylofy
git apply --reject --whitespace=fix /pad/naar/shop3345_extractor_fix.diff
python -m py_compile scripts/scrapers/shop3345.py
```

## Smoke-test
```bash
python tools/shop3345_smoketest.py --module scripts/scrapers/shop3345.py
```

Verwacht resultaat op bekende pagina's zoals ABBA / Pink Floyd:
- EAN gevuld
- prijs gevuld
- `availability=in_stock`
