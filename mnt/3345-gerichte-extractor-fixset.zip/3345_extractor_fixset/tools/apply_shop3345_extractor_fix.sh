#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-.}"
PATCH_FILE="$(cd "$(dirname "$0")"/../patches && pwd)/shop3345_extractor_fix.diff"

cd "$REPO_ROOT"
git apply --reject --whitespace=fix "$PATCH_FILE"
python -m py_compile scripts/scrapers/shop3345.py
echo "Patch applied and syntax check passed."
