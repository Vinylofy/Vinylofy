#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import sys
from pathlib import Path

import requests


def load_module(module_path: Path):
    spec = importlib.util.spec_from_file_location("shop3345_module", module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module from {module_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules["shop3345_module"] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description="Smoke-test the 3345 extractor on known product pages.")
    parser.add_argument(
        "--module",
        default="scripts/scrapers/shop3345.py",
        help="Path to the shop3345.py file you want to test.",
    )
    parser.add_argument(
        "--url",
        action="append",
        dest="urls",
        help="Product URL to test. Can be used multiple times.",
    )
    args = parser.parse_args()

    urls = args.urls or [
        "https://3345.nl/products/abba-gold",
        "https://3345.nl/products/pink-floyd-wish-you-were-here-50th-anniversary-edition-yellow-flame-vinyl-lp",
    ]

    module = load_module(Path(args.module).resolve())
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": "Mozilla/5.0",
            "Accept-Language": "en-US,en;q=0.9,nl;q=0.8",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        }
    )

    for url in urls:
        html = session.get(url, timeout=30).text
        row = module.extract_detail_fields(html, url)
        print(
            f"{url}\n"
            f"  artist={row.get('artist')}\n"
            f"  title={row.get('title')}\n"
            f"  ean={row.get('ean')}\n"
            f"  price={row.get('price')}\n"
            f"  availability={row.get('availability')}\n"
            f"  detail_status={row.get('detail_status')}\n"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
